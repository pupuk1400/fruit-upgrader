renderWheel(undefined);

// ==================== МУЛЬТИВЫБОР СТАВКИ (патч) ====================
// Переопределяем функции, чтобы работал мультивыбор

window.getBetTotal = function() {
  return state.selectedItems.reduce((s,i)=>s+i.value, 0);
};

window.toggleSelectItem = function(item) {
  if (state.isUpgrading) return;
  const idx = state.selectedItems.findIndex(i => i.id === item.id);
  if (idx >= 0) state.selectedItems.splice(idx, 1);
  else state.selectedItems.push(item);
  renderInventory();
  renderSelectedInfo();
  renderMultiBigSlot();
  updateChanceDisplay();
  updateUpgradeBtn();
  updateWheelFromChance();
  renderShop();
};

window.renderMultiBigSlot = function() {
  const el = $('slotLeft');
  if (state.selectedItems.length === 0) {
    el.className = 'big-slot empty-slot';
    el.innerHTML = 'Выбери<br>предмет(ы)';
    return;
  }
  const total = getBetTotal();
  const emojis = state.selectedItems.slice(0,4).map(i=>i.emoji).join('');
  const more = state.selectedItems.length > 4 ? `+${state.selectedItems.length-4}` : '';
  const rarities = state.selectedItems.map(i=>Object.keys(RARITIES).indexOf(i.rarity));
  const maxIdx = Math.max(...rarities);
  const topRarity = Object.keys(RARITIES)[maxIdx];
  const r = RARITIES[topRarity];
  el.className = `big-slot rarity-${topRarity}`;
  el.innerHTML = `
    <div style="font-size:2rem;line-height:1;filter:drop-shadow(0 0 12px ${r.color});">${emojis}${more}</div>
    <div class="item-value" style="font-size:0.9rem;color:#7dff9e;">${total.toLocaleString('ru-RU')} 🌱</div>
    <div class="item-rarity-label">${state.selectedItems.length} шт.</div>`;
};

// Инициализируем массив выбранных
state.selectedItems = state.selectedItems || [];

// Перепривязываем кнопку "Очистить ставку"
$('clearBetBtn').onclick = () => {
  state.selectedItems = [];
  renderInventory();
  renderSelectedInfo();
  renderMultiBigSlot();
  updateChanceDisplay();
  updateUpgradeBtn();
  updateWheelFromChance();
  renderShop();
};

renderMultiBigSlot();
card.onclick = () => toggleSelectItem(item);
if (state.selectedItems.some(si => si.id === item.id)) card.classList.add('selected-multi');
if (!state.selectedItems || state.selectedItems.length === 0) {
  const it = state.selectedItem;
const r = RARITIES[it.rarity];
info.innerHTML = `...
const total = state.selectedItems.reduce((s,i)=>s+i.value, 0);
const emojis = state.selectedItems.slice(0,6).map(i=>i.emoji).join(' ');
info.innerHTML = `
  <div style="font-size:2.2rem;">${emojis}</div>
  <div style="font-size:1.8rem;font-weight:800;color:#7dff9e;text-shadow:0 0 20px #7dff9e;">${total.toLocaleString('ru-RU')} 🌱</div>
  <div style="color:#c080ff;font-size:0.75rem;">${state.selectedItems.length} предмет(ов)</div>`;
return;

